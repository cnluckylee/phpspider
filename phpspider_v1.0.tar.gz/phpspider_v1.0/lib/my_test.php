<?php
class MyTest {
        function __construct() {
                     echo "my lib test";
        }
}


